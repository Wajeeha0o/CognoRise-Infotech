function appendCharacter(character) {
    let display = document.getElementById('display');
    display.value += character;
}

function calculateResult() {
    let display = document.getElementById('display');
    let expression = display.value;

    if (expression) {
        let result = eval(expression.replace('×', '*').replace('÷', '/'));
        if (!isNaN(result)) {
            display.value = result;
        } else {
            display.value = 'Error';
        }
    }
}

function clearDisplay() {
    document.getElementById('display').value = '';
}

function deleteLast() {
    let display = document.getElementById('display');
    display.value = display.value.slice(0, -1);
}

document.addEventListener('keydown', function(event) {
    const key = event.key;
    const operators = '+-*/%.';

    if (!isNaN(key) || operators.includes(key)) {
        appendCharacter(key === '*' ? '×' : key === '/' ? '÷' : key);
    } else if (key === 'Enter') {
        calculateResult();
    } else if (key === 'Backspace') {
        deleteLast();
    } else if (key.toLowerCase() === 'c') {
        clearDisplay();
    }
});
