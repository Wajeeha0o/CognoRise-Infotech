<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

$mysqli = new mysqli("localhost", "root", "", "todo_app");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}


$user_id = $_SESSION['user_id'];
$tasks_query = $mysqli->prepare("SELECT * FROM tasks WHERE user_id = ?");
$tasks_query->bind_param("i", $user_id);
$tasks_query->execute();
$result = $tasks_query->get_result();
$tasks = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['task'])) {
        $task_text = trim($_POST['task']);
        if (!empty($task_text)) {
            $insert_task = $mysqli->prepare("INSERT INTO tasks (user_id, task, status) VALUES (?, ?, 'In Progress')");
            $insert_task->bind_param("is", $user_id, $task_text);
            $insert_task->execute();
            header("Location: home.php");
            exit();
        }
    } elseif (isset($_POST['delete'])) {
        $task_id = $_POST['delete'];
        $delete_task = $mysqli->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
        $delete_task->bind_param("ii", $task_id, $user_id);
        $delete_task->execute();
        header("Location: home.php");
        exit();
    } elseif (isset($_POST['mark_finished'])) {
        $task_id = $_POST['mark_finished'];
        $update_task = $mysqli->prepare("UPDATE tasks SET status = 'Finished' WHERE id = ? AND user_id = ?");
        $update_task->bind_param("ii", $task_id, $user_id);
        $update_task->execute();
        header("Location: home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do App</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 600px;
            text-align: center;
        }

        .logo img {
            width: 150px;
            margin-bottom: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .task-form {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    align-items: center;
}

.task-form textarea {
    width: 80%; 
    padding: 10px;
    font-size: 16px;
    border: 2px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    resize: none; 
}

.task-form button {
    padding: 10px 20px;
    background-color: #5e72eb;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
    margin-left: 10px;
}

.task-form button:hover {
    background-color: #4e62d1;
}

        .logout-btn {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #ff5e57;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
}

.logout-btn:hover {
    background-color: #e04a45;
}

         

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f4f4f4;
        }

        .btn-danger {
            background-color: #ff5e57;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-danger:hover {
            background-color: #e04a45;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        .tick-icon {
            color: green;
            font-size: 18px;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <h2><u><b>To Do App</b></u></h2>

        <div class="task-form">
    <form method="POST" action="home.php">
        <textarea name="task" id="taskInput" placeholder="Enter a task here" rows="2" cols="50"></textarea>
        <button type="submit">Save</button>
    </form>
</div>

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Todo Item</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="taskTable">
                <?php if (!empty($tasks)) : ?>
                    <?php foreach ($tasks as $index => $task) : ?>
                        <tr>
                            <td><?= $index + 1; ?></td>
                            <td><?= htmlspecialchars($task['task']); ?></td>
                            <td><?= htmlspecialchars($task['status']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <button type="submit" name="delete" value="<?= $task['id']; ?>" class="btn-danger">Delete</button>
                                </form>
                                <?php if ($task['status'] === 'In Progress') : ?>
                                    <form method="POST" style="display:inline;">
                                        <button type="submit" name="mark_finished" value="<?= $task['id']; ?>" class="btn-success">Finished</button>
                                    </form>
                                <?php else : ?>
                                    <i class="fas fa-check tick-icon"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4">No tasks found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="index.html" class="logout-btn">Logout</a>
    </div>
  
</body>
</html>
