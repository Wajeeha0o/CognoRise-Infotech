<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "quiz_app");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$subject = $_POST['subject'];
$score = 0;


if ($subject == 'Biology') {
    if ($_POST['question1'] == 'b') $score++;
    if ($_POST['question2'] == 'c') $score++;
    if ($_POST['question3'] == 'd') $score++;
    if ($_POST['question4'] == 'b') $score++;
    if ($_POST['question5'] == 'a') $score++;
}

if ($subject == 'Physics') { 
    if ($_POST['question1'] == 'd') $score++;
    if ($_POST['question2'] == 'a') $score++;
    if ($_POST['question3'] == 'c') $score++;
    if ($_POST['question4'] == 'b') $score++;
    if ($_POST['question5'] == 'a') $score++;
}

if ($subject == 'Chemistry') { 
    if ($_POST['question1'] == 'a') $score++;
    if ($_POST['question2'] == 'a') $score++;
    if ($_POST['question3'] == 'a') $score++;
    if ($_POST['question4'] == 'a') $score++;
    if ($_POST['question5'] == 'b') $score++;
}

$total_questions = 5; 
$percentage = ($score / $total_questions) * 100;

$user_id = $_SESSION['user_id'];


$stmt = $mysqli->prepare("INSERT INTO results (user_id, subject, score) VALUES (?, ?, ?)");
if ($stmt) {
    $stmt->bind_param("isd", $user_id, $subject, $percentage);
    if ($stmt->execute()) {
        header("Location: home.php");
    } else {
        echo "Error executing query: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Error preparing statement: " . $mysqli->error;
}

$mysqli->close();
?>
