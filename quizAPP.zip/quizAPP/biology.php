<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biology Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('biology1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border: 10px solid #000; 
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .question {
            margin-bottom: 15px;
        }

        .question p {
            font-weight: bold;
        }

        .question input {
            margin-right: 10px;
        }

        .submit-btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Biology Quiz</h1>
        <form action="quiz_process.php" method="post">
            <div class="question">
                <p>1. What is the powerhouse of the cell?</p>
                <input type="radio" name="question1" value="a" required> Nucleus<br>
                <input type="radio" name="question1" value="b"> Mitochondria<br>
                <input type="radio" name="question1" value="c"> Ribosome<br>
                <input type="radio" name="question1" value="d"> Golgi apparatus
            </div>

            <div class="question">
                <p>2. What is the basic unit of life?</p>
                <input type="radio" name="question2" value="a" required> Atom<br>
                <input type="radio" name="question2" value="b"> Molecule<br>
                <input type="radio" name="question2" value="c"> Cell<br>
                <input type="radio" name="question2" value="d"> Tissue
            </div>

            <div class="question">
                <p>3. Which organelle is responsible for energy production in cells?</p>
                <input type="radio" name="question3" value="a" required> Nucleus<br>
                <input type="radio" name="question3" value="b"> Ribosome<br>
                <input type="radio" name="question3" value="c"> Chloroplast<br>
                <input type="radio" name="question3" value="d"> Mitochondria
            </div>

            <div class="question">
                <p>4. The physical appearance of an organism as a result of its genotype is called:</p>
                <input type="radio" name="question4" value="a" required> Genotype<br>
                <input type="radio" name="question4" value="b"> Phenotype<br>
                <input type="radio" name="question4" value="c"> Allele<br>
                <input type="radio" name="question4" value="d"> Trait
            </div>

            <div class="question">
                <p>5. The process by which plants lose water vapor through small openings in their leaves is called:</p>
                <input type="radio" name="question5" value="a" required> Transpiration<br>
                <input type="radio" name="question5" value="b"> Photosynthesis<br>
                <input type="radio" name="question5" value="c"> Respiration<br>
                <input type="radio" name="question5" value="d"> Germination
            </div>

            <input type="hidden" name="subject" value="Biology">
            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>
</body>
</html>
