<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chemistry Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('chemistry1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border: 10px solid #000; 
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .question {
            margin-bottom: 15px;
        }

        .question p {
            font-weight: bold;
        }

        .question input {
            margin-right: 10px;
        }

        .submit-btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Chemistry Quiz</h1>
        <form action="quiz_process.php" method="post">
            <div class="question">
                <p>1. What is the atomic number of Carbon?</p>
                <input type="radio" name="question1" value="a" required> 6<br>
                <input type="radio" name="question1" value="b"> 8<br>
                <input type="radio" name="question1" value="c"> 12<br>
                <input type="radio" name="question1" value="d"> 14
            </div>

            <div class="question">
                <p>2. What is the chemical symbol for Gold?</p>
                <input type="radio" name="question2" value="a" required> Au<br>
                <input type="radio" name="question2" value="b"> Ag<br>
                <input type="radio" name="question2" value="c"> Fe<br>
                <input type="radio" name="question2" value="d"> Pb
            </div>

            <div class="question">
                <p>3. Which of the following is an alkali metal?</p>
                <input type="radio" name="question3" value="a" required> Sodium<br>
                <input type="radio" name="question3" value="b"> Magnesium<br>
                <input type="radio" name="question3" value="c"> Calcium<br>
                <input type="radio" name="question3" value="d"> Iron
            </div>

            <div class="question">
                <p>4. What is the pH of a neutral solution?</p>
                <input type="radio" name="question4" value="a" required> 7<br>
                <input type="radio" name="question4" value="b"> 0<br>
                <input type="radio" name="question4" value="c"> 14<br>
                <input type="radio" name="question4" value="d"> 3
            </div>

            <div class="question">
                <p>5. What type of bond is formed between two nonmetals?</p>
                <input type="radio" name="question5" value="a" required> Ionic<br>
                <input type="radio" name="question5" value="b"> Covalent<br>
                <input type="radio" name="question5" value="c"> Metallic<br>
                <input type="radio" name="question5" value="d"> Hydrogen
            </div>

            <input type="hidden" name="subject" value="Chemistry">
            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>
</body>
</html>
