<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physics Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('physics.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border: 10px solid #000; 
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .question {
            margin-bottom: 15px;
        }

        .question p {
            font-weight: bold;
        }

        .question input {
            margin-right: 10px;
        }

        .submit-btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Physics Quiz</h1>
        <form action="quiz_process.php" method="post">
            <div class="question">
                <p>1. What is the speed of light in vacuum?</p>
                <input type="radio" name="question1" value="a" required> 300,000 km/s<br>
                <input type="radio" name="question1" value="b"> 150,000 km/s<br>
                <input type="radio" name="question1" value="c"> 1,080 km/h<br>
                <input type="radio" name="question1" value="d"> 299,792 km/s
            </div>

            <div class="question">
                <p>2. What is the unit of force?</p>
                <input type="radio" name="question2" value="a" required> Newton<br>
                <input type="radio" name="question2" value="b"> Joule<br>
                <input type="radio" name="question2" value="c"> Pascal<br>
                <input type="radio" name="question2" value="d"> Watt
            </div>
            
            <div class="question">
                <p>3. The energy of a photon is directly proportional to:</p>
                <input type="radio" name="question3" value="a" required> Its speed.<br>
                <input type="radio" name="question3" value="b"> Its wavelength.<br>
                <input type="radio" name="question3" value="c"> Its frequency.<br>
                <input type="radio" name="question3" value="d"> Its amplitude.
            </div>

            <div class="question">
                <p>4. The centripetal force acting on an object moving in a circle is directed:</p>
                <input type="radio" name="question4" value="a" required> Away from the center of the circle.<br>
                <input type="radio" name="question4" value="b"> Towards the center of the circle.<br>
                <input type="radio" name="question4" value="c"> Tangential to the circle.<br>
                <input type="radio" name="question4" value="d"> In the direction of the object's velocity.
            </div>
            
            <div class="question">
                <p>5. The value of acceleration due to gravity on the surface of Earth is approximately</p>
                <input type="radio" name="question5" value="a" required>  9.8 m/s².<br>
                <input type="radio" name="question5" value="b">  10.8 m/s².<br>
                <input type="radio" name="question5" value="c">  90.8 m/s².<br>
                <input type="radio" name="question5" value="d">  7.8 m/s².
            </div>
            <input type="hidden" name="subject" value="Physics">
            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>
</body>
</html>
