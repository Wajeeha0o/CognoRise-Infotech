<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "quiz_app");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Function to validate email
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to validate password
function validate_password($password) {
    // Password must be at least 8 characters long, contain at least one letter, one number, and one special character
    $pattern = "/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
    return preg_match($pattern, $password);
}

// Handling signup request
if (isset($_POST['signup'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate email and password
    if (!validate_email($username)) {
        die("Invalid email format.");
    }
    if (!validate_password($password)) {
        die("Password must be at least 8 characters long, and include at least one letter, one number, and one special character.");
    }

    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $mysqli->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password_hash);
    if ($stmt->execute()) {
        header("Location: index.html");
        exit();
    } else {
        echo "Signup failed. Please try again.";
    }
}

// Handling login request
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate email format
    if (!validate_email($username)) {
        die("Invalid email format.");
    }

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: home.php");  // Assuming home.php exists
        exit();
    } else {
        echo "Invalid username or password.";
    }
}
?>
