<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "quiz_app");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the user's quiz results
$stmt = $mysqli->prepare("SELECT subject, score FROM results WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$results = [];
while ($row = $result->fetch_assoc()) {
    $results[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz App Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('school.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
        }

        .container {
            text-align: center;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        h1 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .category-list {
            list-style-type: none;
            padding: 0;
            margin: 20px 0;
        }

        .category-list li {
            margin: 10px 0;
        }

        .category-list a {
            display: block;
            padding: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            font-size: 1.2em;
            transition: background-color 0.3s;
        }

        .category-list a:hover {
            background-color: #0056b3;
        }

        .logout-btn {
            display: block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
        }

        .logout-btn:hover {
            background-color: #c82333;
        }

        .results-section {
            margin-top: 30px;
            text-align: left;
        }

        .results-section h2 {
            font-size: 1.5em;
        }

        .results-section ul {
            list-style-type: none;
            padding: 0;
        }

        .results-section li {
            margin: 5px 0;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Quiz App</h1>
        <ul class="category-list">
            <li><a href="biology.php">Biology</a></li>
            <li><a href="physics.php">Physics</a></li>
            <li><a href="chemistry.php">Chemistry</a></li>
        </ul>
        <a href="index.html" class="logout-btn">Logout</a>

        <div class="results-section">
            <h2>Previous Marks</h2>
            <ul>
                <?php foreach ($results as $result): ?>
                    <li><?php echo htmlspecialchars($result['subject']) . ": " . htmlspecialchars($result['score']) . "%"; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
